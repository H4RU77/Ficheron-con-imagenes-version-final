
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ficheroconimagenes;


/**
 *
 * @author harum
 */
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author harum
 */
public class Logger {
    
    private File log;
    
    public void validar(){
        //crear file 
    log= new File("C:\\Users\\harum\\OneDrive\\Documentos\\NetBeansProjects\\FicheroConImagenes\\imagenes.imagenes");
        try{
            if(!log.exists()){
                log.createNewFile();
            }
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        
        }
        
    }
    
     }
    
    
    
    
    

